import asyncio
import sys
from os import getenv
from dotenv import load_dotenv
import logging


load_dotenv()


TOKEN = getenv("BOT_TOKEN")

if not TOKEN:
    print("Ошибка: BOT_TOKEN не найден в .env файле или переменных окружения")
    sys.exit(1)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

async def main() -> None:
    from aiogram import Bot, Dispatcher
    
    from handlers import setup_routers

    bot = Bot(token=TOKEN)
    dp = Dispatcher()

    router = setup_routers()
    dp.include_router(router)

    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())