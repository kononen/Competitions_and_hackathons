from aiogram import Router

def setup_routers():
    from . import start_bot
    from . import user_request

    router = Router()

    router.include_routers(start_bot.router, user_request.router)

    return router