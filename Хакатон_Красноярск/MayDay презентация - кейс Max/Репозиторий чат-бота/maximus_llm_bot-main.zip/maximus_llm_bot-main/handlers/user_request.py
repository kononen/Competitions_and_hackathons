from aiogram import Router
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from states.user_states import UserStates
from os import getenv
from dotenv import load_dotenv
from llm.llm import *

load_dotenv()

router = Router()

@router.message(UserStates.USER_REQUEST)
async def user_request(message: Message, state: FSMContext) -> None:
    """Обработка запроса пользователя"""
    processing_msg = None
    try:
        # Получаем текущее состояние пользователя
        data = await state.get_data()
        current_messages = data.get('messages', [])
        current_agent = data.get('agent', None)
        
        # Отправляем сообщение о обработке и сохраняем объект
        processing_msg = await message.answer("🤔 Обрабатываю ваш запрос...")
        
        if current_agent:
            agent = current_agent
        else:
            agent = create_agent_graph()
            await state.update_data(agent=agent)

        thread_id = f"user_{message.from_user.id}_conversation"
        config = {"configurable": {"thread_id": thread_id}}

        current_messages.append(HumanMessage(content=message.text))

        result = agent.invoke({"messages": current_messages}, config)

        updated_messages = result['messages']
        
        await state.update_data(messages=updated_messages)

        last_message = updated_messages[-1]
        if isinstance(last_message, AIMessage):
            await message.answer(f"🤖 {last_message.content}")
            await processing_msg.delete()
            
        if 'current_step' in result:
            if result['current_step'] in ["end_conversation", "dialog_finished", "registration_completed", 'no_events_found']:
                agent = create_agent_graph()
                await state.update_data(agent=agent)
            print(f"[Шаг: {result['current_step']}]")
            
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        import traceback
        traceback.print_exc()
        await message.answer("❌ Произошла ошибка при обработке запроса")
        
