from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from states.user_states import UserStates
from keyboard.esia_keyboard_builder import get_esia_authorization_keyboard
from aiogram import Router, F
from aiogram.types import CallbackQuery
from asyncio import sleep

router = Router()

@router.message(Command("start"))
async def command_start_handler(message: Message, state: FSMContext) -> None:
    await state.set_state(UserStates.GOSUSLUGI_IDENTIFICATION)

    await message.answer(
        f"👋 Здравствуйте, {message.from_user.first_name}! "
        "Вас приветствует умный бот Максимус 🤖\n\n"
        "📍 Перед началом пользования ботом необходимо пройти авторизацию.",
        reply_markup=get_esia_authorization_keyboard()
    )


@router.callback_query(F.data == "esia_authorization")
async def process_esia_auth(callback: CallbackQuery, state: FSMContext):
    await callback.message.edit_text(
        "🔄 Перенаправляю на авторизацию ЕСИА...",
        reply_markup=None  
    )

    await sleep(2)

    await callback.message.edit_text(
        "✅ Вы успешно прошли тестовую авторизацию в ЕСИА!\n\n"
        "💭 Напишите мне ваш вопрос, а я попытаюсь вам на него ответить.",
        reply_markup=None  
    )
    
    await state.set_state(UserStates.USER_REQUEST)



