from aiogram.types import (
    InlineKeyboardButton
)
from aiogram.utils.keyboard import (
    InlineKeyboardBuilder
)

def get_esia_authorization_keyboard():
    """Клавиатура для подтверждения персональных данных"""
    builder = InlineKeyboardBuilder()
    
    builder.row(
        InlineKeyboardButton(
            text="Авторизация с помощью ЕСИА",
            callback_data="esia_authorization"
        )
    )

    return builder.as_markup()