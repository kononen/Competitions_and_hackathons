from aiogram.fsm.state import State, StatesGroup

class UserStates(StatesGroup):   
    GOSUSLUGI_IDENTIFICATION = State()

    USER_REQUEST = State()  
